document.addEventListener('DOMContentLoaded', function() {
    const emailInput = document.querySelector('.email');
    const passwordInput = document.querySelector('.pass');
    const submitButton = document.querySelector('.submit');

    submitButton.addEventListener('click', function(event) {
        event.preventDefault(); // Prevent the default form submission behavior

        // Validate email format
        if (!validateEmail(emailInput.value)) {
            alert('Please enter a valid email address.');
            return;
        }

        // Validate password strength
        if (passwordInput.value.length < 8) {
            alert('Password must be at least 8 characters long.');
            return;
        }

        // If both email and password are valid, proceed with signup
        alert('Sign up successful!');
        // You can add further actions here, like submitting the form data to a server
    });

    // Function to validate email format
    function validateEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
});
